Prashanna V — portfolio (multi-page)

Open index.html in a browser. Keep all folders together.

index.html                                   Home
work/index.html                              Work
work/wheres-my-money/index.html              Case study 01
work/streaming-heuristic-evaluation/index.html   Case study 02
work/user-experience-analysis/index.html     Case study 03
about/index.html                             About
experience/index.html                        Experience
lab/index.html                               Lab
contact/index.html                           Contact

The folder layout mirrors the live site's URLs, so it can be uploaded to any static host as-is.
